# BE - Take Home Test

- [Variant 1](/01/)
- [Variant 2](/02/)